__version__ = "0.2.1.9000"

from ._core import icon_svg, metadata

__all__ = (
    "icon_svg",
    "metadata",
)
