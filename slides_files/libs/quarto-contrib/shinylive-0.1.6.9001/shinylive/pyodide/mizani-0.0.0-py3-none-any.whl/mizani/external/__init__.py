from .xkcd_rgb import xkcd_rgb
from .crayon_rgb import crayon_rgb

__all__ = ['xkcd_rgb', 'crayon_rgb']
