def get_color_contrast(color: str) -> str:
    # TODO-future: Implement
    return color
