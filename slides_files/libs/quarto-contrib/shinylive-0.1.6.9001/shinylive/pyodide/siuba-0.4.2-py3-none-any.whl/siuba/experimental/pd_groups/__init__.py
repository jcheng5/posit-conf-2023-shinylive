from .dialect import fast_mutate, fast_filter, fast_summarize
